<div id="app">
  <ul>
  <li v-for="product in products">
    {{product}}
    </li>
</ul>
</div>

<script scr="https://unpkg.com/vue"></script>
<script>
  const app = new vue({
    el:"#app",
    data:{
      products:["groceries", "exercise", "washing", "cleaning car"]
    }
  })