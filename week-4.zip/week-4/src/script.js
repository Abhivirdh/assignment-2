var app = new Vue({
  el: '#app',
  data: {
    seen: true
  }
})
app.seen = true;