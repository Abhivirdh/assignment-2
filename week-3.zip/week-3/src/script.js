let text = "how many letters is this?";
document.getElementById("letters").innerHTML = text.length;


let str = "this is the 2 string method";
document.getElementById("demo").innerHTML = str.toString();



const fruits = ["assignment 1", "assignment 2", "assignmetn 3", "submissions"];
document.getElementById("join").innerHTML = fruits.join(" and ");


function mytimedFunction() {
  var a = new Date();
  var b = a.getTime();
  document.getElementById("timed").innerHTML = b;
}


function myFunction() {
  var x = new Date();
  var y = x.getFullYear();
  document.getElementById("year").innerHTML = y;
}


