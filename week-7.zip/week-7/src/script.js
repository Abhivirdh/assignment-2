const UserName = {
  props: {
    firstName: String,
    lastName: String
  },
  template: `
    <input 
      type="text"
      :value="firstName"
      @input="$emit('update:firstName', $event.target.value)">

    <input
      type="text"
      :value="lastName"
      @input="$emit('update:lastName', $event.target.value)">
  `
};

const HelloVueApp = {
  components: {
    UserName,
  },
  data() {
    return {
      firstName: 'John',
      lastName: 'Doe',
    };
  },
};

Vue.createApp(HelloVueApp).mount('#v-model-example')




Vue.component('child-component', {
  template: '#child-component',
  data() {
      return {
        childTitle: 'title from child component',
        childSubtitle: 'subtitle from child component'
      }
  },
  props:{
    subtitle: {
      type: String,
      required: true
    }
  }
})

new Vue ({
  el: '#app',
  data() {
      return {
        title: 'Hello Vue',
        subtitle: 'how to use slots'
    }
  }
})