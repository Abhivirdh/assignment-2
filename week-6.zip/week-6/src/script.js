Vue.createApp({
  data() {
    return {
      message: ''
    }
  }
}).mount('#v-model-basic')






Vue.createApp({
  data() {
    return {
      checkedNames: []
    }
  }
}).mount('#v-model-multiple-checkboxes')


Vue.createApp({
  data() {
    return {
      selected: 'A',
      options: [
        { text: 'A: YES', value: 'A' },
        { text: 'B: NO', value: 'B' },
        { text: 'C: MAYBE', value: 'C' }
      ]
    }
  }
}).mount('#v-model-select-dynamic')

